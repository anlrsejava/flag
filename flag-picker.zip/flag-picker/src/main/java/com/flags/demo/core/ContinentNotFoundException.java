package com.flags.demo.core;

public class ContinentNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public ContinentNotFoundException() {
	}

}
