package com.flags.demo.core;

public class FlagNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public FlagNotFoundException() {
	}

}
